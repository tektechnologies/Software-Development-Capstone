<!doctype html>
<html lang="en-US">
<?php include('library/head_section.html');?>
<?php include('library/nav.html');?>
<body>
	<div id="main">
	<img src="../images/background.jpg" id="home_img">
	</div>
</body>
<?php include('library/footer.html');?>
</html>