<!doctype html>
<html lang="en-US">
<?php include('library/head_section.html');?>
<?php include('library/nav.html');?>
<body>
	<div class="container" id="main">
	<h1 style="margin-top:2.5em;">Career Pathways</h1>
	<p>One of our goals is to help guide those looking to build a career in the IT field in the right path.</p>
		<div class="card" style="width: 18rem;">
		  <img class="card-img-top" src="..." alt="Card image cap">
		  <div class="card-body">
			<h5 class="card-title">Application Design</h5>
			<p class="card-text">Computer systems need two major elements to work: hardware and software. Hardware is the part of computer systems that you can physically touch (e.g. keyboard, monitor). Software is a collection of instructions that allow a computer to work (e.g. apps). Careers in application design involve creating new application software or improving existing software.</p>
			<a href="#" class="btn btn-primary">Learn more</a>
		  </div>
		</div>
		<div class="card" style="width: 18rem;">
		  <img class="card-img-top" src="..." alt="Card image cap">
		  <div class="card-body">
			<h5 class="card-title">Client Relations</h5>
			<p class="card-text">Client Relations & Customer Service occupations work with clients to understand their needs and help companies develop products that meet those needs. This area ensures that IT projects run smoothly throughout the various phases of sales, development, and delivery.</p>
			<a href="#" class="btn btn-primary">Learn more</a>
		  </div>
		</div>
	</div>
</body>
<?php include('library/footer.html');?>
</html>